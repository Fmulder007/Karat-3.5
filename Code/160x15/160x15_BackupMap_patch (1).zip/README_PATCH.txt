160x15b — патч карты BackupMap
================================

Источник: https://github.com/Fmulder007/Karat-3.5/blob/main/Code/160x15/160x15.ino

Что изменено
------------
Только блок констант и обращений к карте backup во внутренней EEPROM МК.

- Разрозненные #define BACKUP_* заменены на namespace BackupMap { enum : uint16_t { ... } }.
- Смещения trailer вычисляются из размеров payload.
- static_assert фиксируют совместимость с прежним layout
  (SignatureOff==504, CommitOffset==507, CrcOffset==508, SlotSize==510, CrcLength==507).
- Добавлен backupAddr(slot, offset).
- Версия на экране: 160x15b.

Исправление CrcLength
---------------------
В черновике патча ошибочно могло получиться CrcLength = CrcOffset (508),
тогда в CRC попадал бы commit marker (смещение 507).

Правильно (как в оригинале):
  CrcLength = CommitOffset = 507
  — CRC по байтам [0 .. 506];
  commit (507) и поле CRC (508..509) в расчёт не входят.

Бинарный layout и алгоритм CRC совместимы со стоковой прошивкой.

Что не трогалось
----------------
Кольцевая память AT24C32, memory(), CW/PTT, меню, Si5351, экран и т.д.
