160x15b — патч карты BackupMap
================================

Источник: https://github.com/Fmulder007/Karat-3.5/blob/main/Code/160x15/160x15.ino

Что изменено
------------
Только блок констант и обращений к карте backup во внутренней EEPROM МК.

- Разрозненные #define BACKUP_* заменены на namespace BackupMap { enum : uint16_t { ... } }.
- Смещения trailer (signature / version / slot / commit / CRC) вычисляются из размеров payload,
  а не заданы «магическими» 504/507/508.
- Добавлены static_assert, фиксирующие численную совместимость с прежним layout
  (SignatureOff==504, CommitOffset==507, CrcOffset==508, SlotSize==510).
- Добавлен вспомогательный backupAddr(slot, offset) — пока используется по желанию;
  все прежние backupReadByte(base + ...) сохранены по смыслу.
- Версия на экране: 160x15b (чтобы отличить от стоковой 160x15).

Бинарный layout слота НЕ изменён. Уже записанные backup остаются читаемыми.

Что не трогалось
----------------
Кольцевая память AT24C32, memory(), CW/PTT, меню, Si5351, экран и т.д.

Проверка после прошивки
-----------------------
1. Собрать тем же ядром GyverCore, что и раньше.
2. Backup в слот 1 и 2, restore, отказ на пустом/битом слоте.
3. Если static_assert сработал при сборке — значит изменился sizeof(general_set)
   или BAND_RECORD_SIZE; layout нужно пересмотреть осознанно.

